target("WeaselUI")
  set_kind("static")
  add_files("./*.cpp")

