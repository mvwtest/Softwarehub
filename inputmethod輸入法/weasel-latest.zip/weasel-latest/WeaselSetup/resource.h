//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WeaselSetup.rc
//
#define IDI_WEASELSETUP                 107
#define IDR_WEASELSETUP                 107
#define IDR_MAINFRAME                   128
#define IDS_STRING_INSTALL              129
#define IDS_STRING_MODIFY               130
#define IDS_STR_INSTALL_FAILED          131
#define IDS_STR_INSTALL_SUCCESS_CAP     132
#define IDS_STR_UNINSTALL_SUCCESS_CAP   133
#define IDS_STR_UNINSTALL_FAILED        134
#define IDS_STR_ERRCANCELFSREDIRECT     135
#define IDS_STR_ERRRECOVERFSREDIRECT    136
#define IDS_STR_ERRREGIME               137
#define IDS_STR_ERRREGTSF               138
#define IDS_STR_ERRREGIMEWRITESVREXE    139
#define IDS_STR_INORUN_FAILED           140
#define IDS_STR_ERRWRITEWEASELROOT      141
#define IDS_STR_INSTALL_SUCCESS_INFO    142
#define IDS_STR_UNINSTALL_SUCCESS_INFO  143
#define IDS_STR_ERR_WRITE_USER_DIR      144
#define IDS_STR_ERR_WRITE_HANT          145
#define IDS_STR_MODIFY_SUCCESS_INFO     146
#define IDS_STR_MODIFY_SUCCESS_CAP      147
#define IDD_INSTALL_OPTIONS             201
#define IDD_DIALOG1                     203
#define IDC_RADIO_CN                    1000
#define IDC_RADIO_TW                    1001
#define IDC_RADIO_DEFAULT_DIR           1002
#define IDC_RADIO_CUSTOM_DIR            1003
#define IDC_EDIT_DIR                    1004
#define IDC_REMOVE                      1005
#define IDC_CHECK1                      1006
#define IDC_CHECK_INSTIME               1006
#define IDC_BUTTON_CUSTOM_DIR           1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
