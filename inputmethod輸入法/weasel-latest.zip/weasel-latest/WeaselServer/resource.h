//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WeaselServer.rc
//
#define IDI_WEASEL                      100
#define IDI_EN                          101
#define IDI_ZH                          102
#define IDI_RELOAD                      103
#define IDR_MENU_POPUP                  105
#define IDI_FULL_SHAPE                  106
#define IDI_HALF_SHAPE                  107
#define IDS_STR_SYSTEM_VERSION_WARNING_CAPTION 300
#define IDS_STR_SYSTEM_VERSION_WARNING  301
#define IDS_STR_UNDER_MAINTENANCE       302
#define ID_WEASELTRAY_QUIT              40001
#define ID_WEASELTRAY_DEPLOY            40002
#define ID_WEASELTRAY_CHECKUPDATE       40003
#define ID_WEASELTRAY_FORUM             40004
#define ID_WEASELTRAY_HOMEPAGE          40005
#define ID_WEASELTRAY_INSTALLDIR        40006
#define ID_WEASELTRAY_USERCONFIG        40007
#define ID_WEASELTRAY_SETTINGS          40008
#define ID_WEASELTRAY_WIKI              40009
#define ID_WEASELTRAY_DICT_MANAGEMENT   40010
#define ID_WEASELTRAY_SYNC              40012
#define ID_WEASELTRAY_ENABLE_ASCII      40013
#define ID_WEASELTRAY_DISABLE_ASCII     40014
#define ID_WEASELTRAY_RERUN_SERVICE     40015
#define ID_WEASELTRAY_LOGDIR            40016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
