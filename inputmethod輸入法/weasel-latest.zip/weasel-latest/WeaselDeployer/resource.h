//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WeaselDeployer.rc
//
#define IDC_MYICON                      2
#define IDD_WEASELDEPLOYER_DIALOG       102
#define IDI_WEASELDEPLOYER              107
#define IDI_SMALL                       108
#define IDR_MAINFRAME                   128
#define IDD_SWITCHER_SETTING            129
#define IDD_STYLE_SETTING               130
#define IDI_DEPLOY                      131
#define IDD_DICT_MANAGEMENT             132
#define IDS_STR_WEASEL                  133
#define IDS_STR_SAD                     134
#define IDS_STR_HAPPY                   135
#define IDS_STR_NOT_REGULAR             136
#define IDS_STR_DEPLOYING_RESTARTREQ    137
#define IDS_STR_DEPLOYING_WAIT          138
#define IDS_STR_SEL_EXPORT_DICT_NAME    139
#define IDS_STR_ERREXPORT_SYNC_UV       140
#define IDS_STR_ERR_EXPORT_UNKNOWN      141
#define IDS_STR_ERR_EXPORT_SNAP_LOST    142
#define IDS_STR_ERR_UNKNOW              143
#define IDS_STR_ERR_UNKNOWN             143
#define IDS_STR_ERR_SUCCESS             144
#define IDS_STR_ERR_EXPORT_FILE_LOST    145
#define IDS_STR_SEL_IMPORT_DICT_NAME    146
#define IDS_STR_ERR_AT_LEAST_ONE_SEL    147
#define IDS_STR_SCHEMA_NAME             148
#define IDS_STR_OPEN                    149
#define IDS_STR_SAVE_AS                 150
#define IDS_STR_ALL_FILES               151
#define IDS_STR_TXT_FILES               152
#define IDS_STR_IMPORTED                153
#define IDS_STR_EXPORTED                154
#define IDS_STR_RECORD_COUNT            155
#define IDS_STR_DICT_SNAPSHOT           156
#define IDS_STR_KCSS_DICT_SNAPSHOT      157
#define IDC_SCHEMA_LIST                 1000
#define IDC_SCHEMA_DESCRIPTION          1001
#define IDC_GET_SCHEMATA                1002
#define IDC_HOTKEYS                     1003
#define IDC_COLOR_SCHEME                1004
#define IDC_SELECT_FONT                 1005
#define IDC_PREVIEW                     1006
#define IDC_USER_DICT_LIST              1007
#define IDC_BACKUP                      1008
#define IDC_RESTORE                     1009
#define IDC_EXPORT                      1010
#define IDC_IMPORT                      1011
#define IDC_STATIC1                     -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
