target("WeaselIPC")
  set_kind("static")
  add_files("./*.cpp")

