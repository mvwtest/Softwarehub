target("WeaselIPCServer")
  set_kind("static")
  add_files("./*.cpp")

