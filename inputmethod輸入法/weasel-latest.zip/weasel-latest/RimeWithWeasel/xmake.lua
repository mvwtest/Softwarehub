target("RimeWithWeasel")
  set_kind("static")
  add_files("./*.cpp")
  add_rules("use_weaselconstants")

